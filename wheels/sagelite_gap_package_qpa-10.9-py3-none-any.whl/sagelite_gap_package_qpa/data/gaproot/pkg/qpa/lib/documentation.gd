DeclareGlobalFunction( "MakeQPADocumentation" );
