#############################################################################
##
#W  init.g               GAP 4 package AtlasRep                 Thomas Breuer
##

if UserPreference( "AtlasRep", "AtlasRepDataDirectory") = fail then
  CallAndInstallPostRestore(function()
    Perform(["datagens", "dataword", "dataext"], function(dirname)
      local package, l, dir;
      package := "AtlasRep";
      dir := GAPInfo.UserGapRoot;
      for l in ["","pkg",package,dirname] do
        dir := Concatenation([dir,"/",l]);
        if not IsDirectoryPath(dir) then
          CreateDir(dir);
        fi;
      od;
      return 0;
    end);
    SetUserPreference( "AtlasRep", "AtlasRepDataDirectory",Concatenation(GAPInfo.UserGapRoot,"/pkg/AtlasRep/"));
  end);
fi;

# Read the declaration part.
ReadPackage( "atlasrep", "gap/userpref.g"  );
ReadPackage( "atlasrep", "gap/bbox.gd"     );
ReadPackage( "atlasrep", "gap/access.gd"   );
if not IsBound( InfoCMeatAxe ) then
  # This file is also part of the C-MeaAxe package.
  ReadPackage( "atlasrep", "gap/scanmtx.gd" );
  ReadPackage( "atlasrep", "gap/scanmtx.gi" );
fi;
ReadPackage( "atlasrep", "gap/types.gd"    );
ReadPackage( "atlasrep", "gap/interfac.gd" );
ReadPackage( "atlasrep", "gap/mindeg.gd"   );
ReadPackage( "atlasrep", "gap/utils.gd"    );

# Read obsolete variable names if this happens also in the GAP library.
if UserPreference( "gap", "ReadObsolete" ) <> false then
  ReadPackage( "atlasrep", "gap/obsolete.gd" );
fi;


#############################################################################
##
#E

