DeclareAttribute( "ErrorProbability", IsNearRing, "mutable" );
