# Notify database attributes
# and Browse overviews of tables, irrationalities, and differences of data.
ReadPackage( "ctbllib", "gap4/ctdbattr.g" );
ReadPackage( "ctbllib", "gap4/brirrat.g" );

# Notify ATLAS related stuff.
ReadPackage( "ctbllib", "gap4/atlasimp.g" );
ReadPackage( "ctbllib", "gap4/atlasbro.g" );

